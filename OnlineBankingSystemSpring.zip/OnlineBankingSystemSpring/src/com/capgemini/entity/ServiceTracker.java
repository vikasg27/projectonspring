package com.capgemini.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;
import javax.ws.rs.DefaultValue;

import org.hibernate.validator.constraints.NotEmpty;
import org.springframework.beans.factory.annotation.Value;

@Entity(name = "ServiceTracker")
@Table(name = "ServiceTracker")
public class ServiceTracker 
{

	@Override
	public String toString() {
		return "ServiceTracker [serviceId=" + serviceId
				+ ", serviceDescription=" + serviceDescription + ", accountId="
				+ accountId + ", serviceRaisedDate=" + serviceRaisedDate
				+ ", serviceStatus=" + serviceStatus + "]";
	}


	@Id
	@Column(name="Service_Id")
	@NotNull(message="Service Id cannot be Null")
	@Min(value=4, message="Minimum 4 and Maximum 10 digits allowed.")
	@GeneratedValue(generator="serv_seq", strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(sequenceName="serv_seq", name="serv_seq", initialValue=1000, allocationSize=1)
	private int serviceId;
	
	@Column(name="Service_Description")
	@NotEmpty(message="Do not keep this field empty")
	private String serviceDescription;
	
	
	@Column(name="Account_Id")
	@NotNull(message="Do not keep this field empty")
	private int accountId;
	
	
	@Column(name="Service_Raised_Date")
	@Temporal(TemporalType.DATE)
	private Date serviceRaisedDate=new Date();
	
	
	@Column(name="Service_Status")
	@NotEmpty(message="Do not keep this field empty")
	@Pattern(regexp="[a-zA-Z]*" , message="Please enter alphabets only")
	private String serviceStatus;


	public int getServiceId() {
		return serviceId;
	}


	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}


	public String getServiceDescription() {
		return serviceDescription;
	}


	public void setServiceDescription(String serviceDescription) {
		this.serviceDescription = serviceDescription;
	}


	public int getAccountId() {
		return accountId;
	}


	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}


	public Date getServiceRaisedDate() {
		return serviceRaisedDate;
	}


	public void setServiceRaisedDate(Date serviceRaisedDate) {
		this.serviceRaisedDate = serviceRaisedDate;
	}


	public String getServiceStatus() {
		return serviceStatus;
	}


	public void setServiceStatus(String serviceStatus) {
		this.serviceStatus = serviceStatus;
	}


	public ServiceTracker() {
		super();
	}


	public ServiceTracker(int serviceId, String serviceDescription,
			int accountId, Date serviceRaisedDate, String serviceStatus) {
		super();
		this.serviceId = serviceId;
		this.serviceDescription = serviceDescription;
		this.accountId = accountId;
		this.serviceRaisedDate = serviceRaisedDate;
		this.serviceStatus = serviceStatus;
	}
	
	
	
	
}
