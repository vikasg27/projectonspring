package com.capgemini.entity;






public abstract class AccountId 
{


	
	private static int accountId;

	public abstract int getAccountId();

	public abstract void setAccountId(int accountId);
	
	
}
