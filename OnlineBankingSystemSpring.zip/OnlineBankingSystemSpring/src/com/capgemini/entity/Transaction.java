package com.capgemini.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


@Entity
@Table(name="Transaction")
public class Transaction 
{
	@Id
	@Column(name="Transaction_Id")
	@GeneratedValue(generator="tran_seq", strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(sequenceName="tran_seq", name="tran_seq", initialValue=2000, allocationSize=1)
	private int transactionId;
	
	@Column(name="Tran_Description")
	private String transactionDesc;
	
	@Column(name="DateofTransaction")
	@Temporal(TemporalType.DATE)
	private Date dateOfTransaction=new Date();
	
	@Column(name="TransactionType")
	private String transactionType;
	
	@Column(name="TranAmount")
	private Double tranAmount;
	
	@Column(name="Account_No")
	private int accountNo;

	public Transaction() {
		super();
	}

	public Transaction(int transactionId, String transactionDesc,
			Date dateOfTransaction, String transactionType, Double tranAmount,
			int accountNo) {
		super();
		this.transactionId = transactionId;
		this.transactionDesc = transactionDesc;
		this.dateOfTransaction = dateOfTransaction;
		this.transactionType = transactionType;
		this.tranAmount = tranAmount;
		this.accountNo = accountNo;
	}
	
	

	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId
				+ ", transactionDesc=" + transactionDesc
				+ ", dateOfTransaction=" + dateOfTransaction
				+ ", transactionType=" + transactionType + ", tranAmount="
				+ tranAmount + ", accountNo=" + accountNo + "]";
	}

	public int getTransactionId() {
		return transactionId;
	}

	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}

	public String getTransactionDesc() {
		return transactionDesc;
	}

	public void setTransactionDesc(String transactionDesc) {
		this.transactionDesc = transactionDesc;
	}

	public Date getDateOfTransaction() {
		return dateOfTransaction;
	}

	public void setDateOfTransaction(Date dateOfTransaction) {
		this.dateOfTransaction = dateOfTransaction;
	}

	public String getTransactionType() {
		return transactionType;
	}

	public void setTransactionType(String transactionType) {
		this.transactionType = transactionType;
	}

	public Double getTranAmount() {
		return tranAmount;
	}

	public void setTranAmount(Double tranAmount) {
		this.tranAmount = tranAmount;
	}

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}
	
}
