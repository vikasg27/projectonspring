package com.capgemini.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.capgemini.entity.AccountMaster;
import com.capgemini.entity.Customer;
import com.capgemini.entity.FundTransfer;
import com.capgemini.entity.PayeeTable;
import com.capgemini.entity.ServiceTracker;
import com.capgemini.entity.Transaction;
import com.capgemini.entity.UserTable;
import com.capgemini.exception.BankingException;


/************************************************************************************
 * File:        BankDaoImpl.java
 * Package:     com.capgemini.dao
 * Description:        Dao class for Online Banking System (user)
 * Version:     3.0
 * Author: Group5            Date:02/02/2017        
 ************************************************************************************/

@Repository
public class UserBankDaoImpl implements IUserBankDao {

	@PersistenceContext
	private EntityManager manager;
	


	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#login(int)
	 */
	@Override
	public UserTable login(int userId) throws BankingException {
		try {
			UserTable user = manager.find(UserTable.class, userId);
			
			if(user == null)
				throw new BankingException("No user Exists");
			else
				return user;
		} catch (Exception e) {
			throw new BankingException("No user Exists");
		}
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#register(com.capgemini.entity.UserTable)
	 */
	@Override
	public boolean register(UserTable user) throws BankingException {
		
		int accountId=user.getAccountId();
		AccountMaster master=manager.find(AccountMaster.class ,accountId);
		
		if(master!=null)
		{
			
			manager.persist(user);
		
		}
		else
			throw new BankingException("Please open new Account at our bank branch.... Contact @1800-5424-800");
		UserTable user_check=manager.find(UserTable.class, user.getUserId());
		if(user_check==null)
			throw new BankingException("Server Error. Contact bank @1800-5424-800");
		else
		
		return true;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#getDetailsMini(int)
	 */
	@Override
	public List<Transaction> getDetailsMini(int accountNo)
			throws BankingException {
		
		List<Transaction> tranlist=new ArrayList<>();
		
		String query="select tran from Transaction tran where accountNo=:paccountId";
		TypedQuery<Transaction> query1 = manager.createQuery(query, Transaction.class);
		query1.setParameter("paccountId", accountNo);
		tranlist=query1.getResultList();
	
		if(tranlist==null)
			return null;
		else
			return tranlist;
		
		
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#serviceView(int)
	 */
	@Override
	public ServiceTracker serviceView(int serviceId)
			throws BankingException {
		ServiceTracker service=manager.find(ServiceTracker.class,serviceId);
		return service;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#changePassword(int, java.lang.String)
	 */
	@Override
	public int changePassword(int userId, String password)
			throws BankingException {
		UserTable user=manager.find(UserTable.class, userId);
		String pass1=user.getLoginPassword();
		user.setLoginPassword(password);
		manager.merge(user);
		String pass2=user.getLoginPassword();
		if(!pass1.equals(pass2))
			return 1;
		else
			throw new BankingException("Server Down... Please Try Again Later....");
	}



	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#ownFundTransfer(int, int, double)
	 */
	@Override
	public void ownFundTransfer(int accountPayer, int accountPayee,
			double amount) throws BankingException, SQLException {
		double payeebalance;
		double payerbalance;
		double currentBalance;
		double currentBalance1;
		
		
		
		try 
		{
			AccountMaster master=manager.find(AccountMaster.class, accountPayer);
			AccountMaster master1=manager.find(AccountMaster.class, accountPayee);
			if(master1 == null)
				throw new BankingException("Payee doesnot exists");
			
			currentBalance=master.getAccountBalance();
			currentBalance1=master1.getAccountBalance();
			
			payerbalance=currentBalance-amount;
			payeebalance=currentBalance1+amount;
			
			if(currentBalance<amount)
				throw new BankingException("Insufficient Balance");
			
			master.setAccountBalance(payerbalance);
			master1.setAccountBalance(payeebalance);
			
			manager.merge(master);
			manager.merge(master1);
						
			FundTransfer fund=new FundTransfer();
			fund.setAccountId(accountPayer);
			fund.setPayeeAccountId(accountPayee);
			fund.setTransferAmount(amount);
			manager.persist(fund);
			
			Transaction tran=new Transaction();
			tran.setAccountNo(accountPayer);
			tran.setTranAmount(amount);
			tran.setTransactionDesc("Fund Transfer");
			tran.setTransactionType("Debit");
			
			manager.persist(tran);
						
			Transaction tran1=new Transaction();
			tran1.setAccountNo(accountPayee);
			tran1.setTranAmount(amount);
			tran1.setTransactionDesc("Fund Transfer");
			tran1.setTransactionType("Credit");
			
			manager.persist(tran1);
		} 
		catch (Exception e) 
		{
			
			throw new BankingException("Unable to transfer contact Bank");
		}
		
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#addPayee(com.capgemini.entity.PayeeTable)
	 */
	@Override
	public void addPayee(PayeeTable payee) throws BankingException 
	{
		AccountMaster master=manager.find(AccountMaster.class, payee.getPayeeAccountId());
		if(master == null)
			throw new BankingException("No account number exist for payee specified");
		try {
			manager.persist(payee);
		} catch (Exception e) {
			
			e.printStackTrace();
			throw new BankingException("Unable to add... Contact bank");
		}
		
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#getUser(int)
	 */
	@Override
	public UserTable getUser(int userId) {
		UserTable user=manager.find(UserTable.class,userId);
		return user;
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#getBalance(int)
	 */
	@Override
	public double getBalance(int accountId) {
		AccountMaster account=manager.find(AccountMaster.class, accountId);
		return account.getAccountBalance();
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#reqCheckBook(com.capgemini.entity.ServiceTracker)
	 */
	@Override
	public int reqCheckBook(ServiceTracker service) throws BankingException {
		
		
		
	
		manager.persist(service);
		
		int servId1=service.getServiceId();
		
		return servId1;
		
	}

	/* (non-Javadoc)
	 * @see com.capgemini.dao.IUserBankDao#fetchPayee(int)
	 */
	@Override
	public List<PayeeTable> fetchPayee(int accountId) {
		List<PayeeTable> payeeList=new ArrayList<>();
		String query="select payee from PayeeTable payee where accountId=:paccountId";
		TypedQuery<PayeeTable> query1 = manager.createQuery(query, PayeeTable.class);
		query1.setParameter("paccountId", accountId);
		payeeList=query1.getResultList();
		if(payeeList==null)
			return null;
		else
			return payeeList;
	}





}
