package com.capgemini.dao;

import com.capgemini.entity.AccountMaster;
import com.capgemini.entity.Customer;
import com.capgemini.entity.ServiceTracker;
import com.capgemini.exception.BankingException;

public interface IBankDao 
{
	 
	/** 
	 * This is user to insert new Customer
	 * @param customer of type Customer
	 * @return integer 
	 * @throws BankingException a userdefined exception to check if operation is successful
	 */
	public int insertAccountHolder(Customer customer) throws BankingException;
	/**
	 * This method is used to insert new AccountHolder
	 * @param account of type AccountMaster
	 * @return integer
	 * @throws BankingException a userdefined exception to check if operation is successful
	 */
	public int insertAccount(AccountMaster account) throws BankingException;
	/**
	 * This method is used by admin to delete a account
	 * @param accountId integer
	 * @return integer
	 * @throws BankingException a userdefined exception to check if operation is successful
	 */
	public int deleteAccount(int accountId) throws BankingException;
	/**
	 * This method is used to fetch ServiceTracker table for a specific ServiceID
	 * @param serviceId integer
	 * @return ServiceTracker type object whose status is updated
	 */
	public ServiceTracker updateTracker(int serviceId);
	/**
	 * This method is used to update status of a request
	 * @param track of type ServiceTracker
	 * @throws BankingException a userdefined exception to check if operation is successful
	 */
	public void updateTrack(ServiceTracker track) throws BankingException;
}
